//
//  Awesome_AlarmTests.h
//  Awesome AlarmTests
//
//  Created by David Gisser on 8/3/13.
//  Copyright (c) 2013 David Gisser. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Awesome_AlarmTests : SenTestCase

@end
