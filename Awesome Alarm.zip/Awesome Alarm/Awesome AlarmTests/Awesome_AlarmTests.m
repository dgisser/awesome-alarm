//
//  Awesome_AlarmTests.m
//  Awesome AlarmTests
//
//  Created by David Gisser on 8/3/13.
//  Copyright (c) 2013 David Gisser. All rights reserved.
//

#import "Awesome_AlarmTests.h"

@implementation Awesome_AlarmTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Awesome AlarmTests");
}

@end
