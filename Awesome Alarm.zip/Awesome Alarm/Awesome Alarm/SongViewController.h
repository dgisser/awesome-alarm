//
//  SongViewController.h
//  Awesome Alarm
//
//  Created by David Gisser on 8/7/13.
//  Copyright (c) 2013 David Gisser. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SongViewController : UITableViewController

@property (strong, nonatomic) id mainDelegate;

@end
